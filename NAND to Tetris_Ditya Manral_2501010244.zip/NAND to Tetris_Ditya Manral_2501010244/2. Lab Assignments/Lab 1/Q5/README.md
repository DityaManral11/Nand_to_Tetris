# Q5 – Complete Hack ALU Using HDL

## Objective
To design and implement the complete Hack Arithmetic Logic Unit (ALU) using Hardware Description Language (HDL). The ALU performs arithmetic and logical operations on two 16-bit inputs.

## Files Included
1. `ALU.hdl` – Main chip that performs arithmetic and logical operations.
2. `Add16.hdl` – Performs 16-bit addition.
3. `Not16.hdl` – Performs bitwise NOT operation.
4. `And16.hdl` – Performs bitwise AND operation.
5. `Mux16.hdl` – Selects between two 16-bit inputs.
6. `Or8Way.hdl` – Helps determine whether the output is zero.

## Working
The Hack ALU uses six control bits to perform different operations:

- `zx` – Sets the x input to zero.
- `nx` – Negates the x input.
- `zy` – Sets the y input to zero.
- `ny` – Negates the y input.
- `f` – Selects AND or ADD operation.
- `no` – Negates the final output.

## Output Flags
- `zr` – Becomes 1 when the output is zero.
- `ng` – Becomes 1 when the output is negative (most significant bit is 1).

## ALU Operations
The ALU supports operations such as:
- Constant zero
- Constant one
- Input x
- Input y
- NOT x
- NOT y
- x + y
- x - y
- y - x
- x AND y
- x OR y

## Conclusion
The complete Hack ALU was implemented using HDL. It performs arithmetic and logical operations based on control signals and generates zero and negative status flags.

## Testing
The ALU should be tested using the provided test script in the Hardware Simulator. Attach simulation output screenshots after successful verification.