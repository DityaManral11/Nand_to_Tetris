# RAM8 and RAM64 Using HDL

## Objective
To design and implement RAM8 and RAM64 memory chips using Hardware Description Language (HDL) through hierarchical memory organization.

## Files Included
1. `RAM8.hdl` – Implements a memory chip with 8 locations, each storing 16-bit data.
2. `RAM64.hdl` – Implements a memory chip with 64 locations, each storing 16-bit data.

## Supporting Chips
- `Register.hdl` – Stores 16-bit data.
- `DMux8Way.hdl` – Selects the register or RAM block for writing.
- `Mux8Way16.hdl` – Selects the stored data for reading.

## Working

### RAM8
- Contains 8 memory locations.
- Uses eight 16-bit Register chips.
- Uses a 3-bit address to select a memory location.
- Supports read and write operations.

### RAM64
- Contains 64 memory locations.
- Uses eight RAM8 chips.
- Uses a 6-bit address to select a memory location.
- The upper 3 address bits select one of the eight RAM8 chips.
- The lower 3 address bits select a location inside the selected RAM8.

## Memory Capacity

| RAM Chip | Memory Locations | Address Bits | Data Width |
|----------|------------------|--------------|------------|
| RAM8 | 8 | 3 | 16 bits |
| RAM64 | 64 | 6 | 16 bits |

## Read and Write Operations
- `load = 1`: Writes input data into the selected memory location.
- `load = 0`: Retains the previously stored data.
- The address input selects the memory location for reading or writing.
- The output displays the stored 16-bit data.

## Conclusion
RAM8 and RAM64 were implemented using HDL through hierarchical design. RAM64 is constructed using eight RAM8 chips, demonstrating modular memory organization.

## Testing
Run the provided RAM8 and RAM64 test scripts in the Hardware Simulator. Attach simulation output screenshots after successful verification.