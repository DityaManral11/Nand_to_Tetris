# Program Counter (PC) Using HDL

## Objective
To design and implement a Program Counter (PC) chip using Hardware Description Language (HDL). The PC stores the address of the next instruction to be executed.

## Files Included
1. `PC.hdl` – Main chip that performs program counter operations.

## Supporting Chips
- `Register.hdl` – Stores the current PC value.
- `Inc16.hdl` – Increments the current value by 1.
- `Mux16.hdl` – Selects the required input based on control signals.

## Working
The Program Counter supports four main operations:

1. Reset: Sets the PC value to 0.
2. Load: Loads a new address from the input.
3. Increment: Increases the current PC value by 1.
4. Hold: Keeps the previous PC value unchanged.

## Priority of Operations
| Priority | Condition | Operation |
|----------|-----------|-----------|
| 1 | reset = 1 | Reset PC to 0 |
| 2 | load = 1 | Load input address |
| 3 | inc = 1 | Increment PC by 1 |
| 4 | All signals = 0 | Hold previous value |

## Inputs and Outputs
- `in[16]` – Input address.
- `load` – Controls loading of a new address.
- `inc` – Controls increment operation.
- `reset` – Resets the counter.
- `out[16]` – Provides the current PC value.

## Conclusion
The Program Counter was implemented using HDL. It performs reset, load, increment, and hold operations to maintain the address of the next instruction.

## Testing
Run the provided PC test script in the Hardware Simulator. Use the Tick and Tock clock operations to verify the output and attach simulation screenshots after successful testing.